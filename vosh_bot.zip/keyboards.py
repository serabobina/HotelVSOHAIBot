from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def profile_kb(profile_id):
    kb = InlineKeyboardMarkup()
    kb.add(
        InlineKeyboardButton("📞 Звоню", callback_data=f"call_{profile_id}"),
        InlineKeyboardButton("⏭ Не звоню", callback_data="skip")
    )
    return kb


def rating_kb(call_id):
    kb = InlineKeyboardMarkup(row_width=5)
    for i in range(1, 6):
        kb.insert(InlineKeyboardButton(f"{i}⭐", callback_data=f"rate_{call_id}_{i}"))

    kb.add(InlineKeyboardButton("❌ Не дозвонился", callback_data=f"fail_{call_id}"))
    return kb
