import sqlite3

conn = sqlite3.connect("database.db")
cursor = conn.cursor()

def init_db():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER,
        room TEXT,
        building TEXT,
        description TEXT,
        rating_avg REAL DEFAULT 0,
        rating_count INTEGER DEFAULT 0,
        calls_total INTEGER DEFAULT 0,
        calls_failed INTEGER DEFAULT 0
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS calls (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_user INTEGER,
        to_user INTEGER,
        status TEXT
    )
    """)

    conn.commit()
