from db import cursor, conn

def add_call(from_user, to_user):
    cursor.execute(
        "INSERT INTO calls (from_user, to_user, status) VALUES (?, ?, ?)",
        (from_user, to_user, "pending")
    )
    conn.commit()

    call_id = cursor.lastrowid

    cursor.execute(
        "UPDATE profiles SET calls_total = calls_total + 1 WHERE telegram_id = ?",
        (to_user,)
    )
    conn.commit()

    return call_id


def rate_call(call_id, score):
    cursor.execute("SELECT to_user FROM calls WHERE id = ?", (call_id,))
    to_user = cursor.fetchone()[0]

    cursor.execute(
        "SELECT rating_avg, rating_count FROM profiles WHERE telegram_id = ?",
        (to_user,)
    )
    avg, count = cursor.fetchone()

    new_avg = (avg * count + score) / (count + 1)

    cursor.execute(
        "UPDATE profiles SET rating_avg = ?, rating_count = rating_count + 1 WHERE telegram_id = ?",
        (new_avg, to_user)
    )

    cursor.execute("UPDATE calls SET status='rated' WHERE id=?", (call_id,))
    conn.commit()


def fail_call(call_id):
    cursor.execute("SELECT to_user FROM calls WHERE id = ?", (call_id,))
    to_user = cursor.fetchone()[0]

    cursor.execute(
        "UPDATE profiles SET calls_failed = calls_failed + 1 WHERE telegram_id = ?",
        (to_user,)
    )

    cursor.execute("UPDATE calls SET status='failed' WHERE id=?", (call_id,))
    conn.commit()
