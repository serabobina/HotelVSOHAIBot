def get_badges(profile):
    badges = []

    calls_total = profile["calls_total"]
    calls_failed = profile["calls_failed"]
    rating = profile["rating_avg"]
    rating_count = profile["rating_count"]

    if calls_total >= 5:
        fail_rate = calls_failed / calls_total

        if fail_rate < 0.2:
            badges.append("🟢 Всегда на связи")
        elif fail_rate < 0.5:
            badges.append("🟡 Иногда отвечает")
        else:
            badges.append("🔴 Призрак")

    if rating_count >= 5:
        if rating >= 4.5:
            badges.append("🌟 Топ собеседник")
        elif rating >= 3.5:
            badges.append("👍 Норм чел")
        elif rating < 2.5:
            badges.append("💀 Опасный")

    if calls_total >= 20:
        badges.append("🔥 Популярный")
    elif calls_total < 5:
        badges.append("🆕 Новичок")

    return badges
