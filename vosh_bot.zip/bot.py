from aiogram import Bot, Dispatcher, executor, types

from config import BOT_TOKEN
from db import init_db, cursor
from keyboards import profile_kb, rating_kb
from services.rating_service import add_call, rate_call, fail_call
from services.badge_service import get_badges

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)


@dp.message_handler(commands=["start"])
async def start(msg: types.Message):
    await msg.answer("Привет! Это бот для ВОШ по инфе 🧠")


@dp.message_handler(commands=["profiles"])
async def show_profile(msg: types.Message):
    cursor.execute("SELECT * FROM profiles ORDER BY RANDOM() LIMIT 1")
    profile = cursor.fetchone()

    if not profile:
        await msg.answer("Нет анкет")
        return

    profile_dict = {
        "telegram_id": profile[1],
        "room": profile[2],
        "building": profile[3],
        "description": profile[4],
        "rating_avg": profile[5],
        "rating_count": profile[6],
        "calls_total": profile[7],
        "calls_failed": profile[8],
    }

    badges = get_badges(profile_dict)

    text = f"""
🏢 {profile_dict['building']}
🚪 {profile_dict['room']}

{profile_dict['description']}

⭐ {round(profile_dict['rating_avg'],2)} ({profile_dict['rating_count']})
📞 {profile_dict['calls_total'] - profile_dict['calls_failed']}/{profile_dict['calls_total']}

🏷 {' • '.join(badges)}
"""

    await msg.answer(text, reply_markup=profile_kb(profile[0]))


@dp.callback_query_handler(lambda c: c.data.startswith("call_"))
async def call_handler(callback: types.CallbackQuery):
    profile_id = int(callback.data.split("_")[1])
    call_id = add_call(callback.from_user.id, profile_id)

    await callback.message.answer(
        "Оцени звонок:",
        reply_markup=rating_kb(call_id)
    )


@dp.callback_query_handler(lambda c: c.data.startswith("rate_"))
async def rate_handler(callback: types.CallbackQuery):
    _, call_id, score = callback.data.split("_")
    rate_call(int(call_id), int(score))
    await callback.message.answer("Оценка сохранена 👍")


@dp.callback_query_handler(lambda c: c.data.startswith("fail_"))
async def fail_handler(callback: types.CallbackQuery):
    call_id = int(callback.data.split("_")[1])
    fail_call(call_id)
    await callback.message.answer("Отмечено как не дозвонился")


if __name__ == "__main__":
    init_db()
    executor.start_polling(dp, skip_updates=True)
